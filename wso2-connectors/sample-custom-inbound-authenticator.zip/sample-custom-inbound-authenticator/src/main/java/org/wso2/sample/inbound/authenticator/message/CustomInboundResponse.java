package org.wso2.sample.inbound.authenticator.message;

import org.wso2.carbon.identity.application.authentication.framework.inbound.IdentityMessageContext;
import org.wso2.carbon.identity.application.authentication.framework.inbound.IdentityResponse;

/**
 * Similar to the class for the custom request, this class represents a subclass of IdentityResponse, which results from
 * the Identity Framework after the authentication steps(s).
 */
public class CustomInboundResponse extends IdentityResponse {

    private String redirectUrl;
    private String token;
    private String username;
    private String password;
    private String requestMethod;

    public String getToken() {
        return token;
    }

    public String getUserName() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setToken(String token) {
        this.token = token;
    }

    protected CustomInboundResponse(IdentityResponseBuilder builder) {
        super(builder);
        this.redirectUrl = ((CustomInboundResponseBuilder) builder).redirectUrl;
        this.token = ((CustomInboundResponseBuilder) builder).token;
        this.username = ((CustomInboundResponseBuilder) builder).username;
        this.password = ((CustomInboundResponseBuilder) builder).password;
        this.requestMethod = ((CustomInboundResponseBuilder) builder).requestMethod;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public String getRequestMethod () {
        return requestMethod;
    }

    /**
     * Here also, the builder class for the IdentityResponse subclass can be found within the class itself.
     * Here, the parameters found in the HTTP response can be picked up and set to the response object as per the need.
     */
    public static class CustomInboundResponseBuilder extends IdentityResponseBuilder {

        private String redirectUrl;
        private String token;
        private String username;
        private String password;
        private String requestMethod;

        public CustomInboundResponseBuilder(IdentityMessageContext context) {
            super(context);
        }

        public void setRedirectUrl(String redirectUrl) {
            this.redirectUrl = redirectUrl;
        }

        public void setRequestMethod(String requestMethod) {
            this.requestMethod = requestMethod;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public void setUserName (String username){
            this.username = username;
        }

        public void setPassword (String password){
            this.password = password;
        }

        public CustomInboundResponse build() {
            return new CustomInboundResponse(this);
        }
    }
}
