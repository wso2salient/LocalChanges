/*
*  Copyright (c) 2015, WSO2 Inc. (http://www.wso2.org) All Rights Reserved.
*
*  WSO2 Inc. licenses this file to you under the Apache License,
*  Version 2.0 (the "License"); you may not use this file except
*  in compliance with the License.
*  You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
package org.wso2.sample.inbound.authenticator.factory;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.wso2.carbon.identity.application.authentication.framework.inbound.HttpIdentityResponse;
import org.wso2.carbon.identity.application.authentication.framework.inbound.HttpIdentityResponseFactory;
import org.wso2.carbon.identity.application.authentication.framework.inbound.IdentityResponse;
import org.wso2.sample.inbound.authenticator.message.CustomInboundResponse;
import org.wso2.sample.inbound.authenticator.util.CustomInboundAuthConfig;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

/**
 * This class represents a factory for custom IdentityResponse instances which will result from the framework,
 * after the authentication step.
 */
public class CustomInboundIdentityResponseFactory extends HttpIdentityResponseFactory {

    private static Logger logger = LoggerFactory.getLogger(CustomInboundIdentityResponseFactory.class);
    public String getName() {
        return "CustomInboundIdentityResponseFactory";
    }

    /**
     * Checks if an incoming IdentityResponse from the framework can be handled by this particular factory.
     * @param identityResponse incoming IdentityResponse from the identity framework
     * @return true if the incoming response is of the type handled by this factory
     */
    @Override
    public boolean canHandle(IdentityResponse identityResponse) {
        return identityResponse instanceof CustomInboundResponse;
    }

    /**
     * Converts the received IdentityResponse instance to an HTTPResponse so that it could be sent to the calling party.
     * This is where the logic for picking up and setting any custom parameters/headers/cookies etc is written.
     * HTTPResponse is built depending on the requested method in SP configuration is GET or POST.
     * @param identityResponse the received and handle-able IdentityResponse instance
     * @return a corresponding HTTPResponse in the form of a builder, so that it could be built on demand
     */
    @Override
    public HttpIdentityResponse.HttpIdentityResponseBuilder create(IdentityResponse identityResponse) {

        HttpIdentityResponse.HttpIdentityResponseBuilder builder
                = new HttpIdentityResponse.HttpIdentityResponseBuilder();

        CustomInboundResponse customInboundResponse = (CustomInboundResponse) identityResponse;

        if (StringUtils.isBlank(customInboundResponse.getToken())) {
            builder.setStatusCode(HttpServletResponse.SC_UNAUTHORIZED);
            builder.setRedirectURL(customInboundResponse.getRedirectUrl());
        } else if (customInboundResponse.getRequestMethod().equals("GET")) {
            builder.setStatusCode(HttpServletResponse.SC_FOUND);
            //builder.addParameter("token", customInboundResponse.getToken());
            builder.addParameter("Username", customInboundResponse.getUserName());
            builder.addParameter("Password", customInboundResponse.getPassword());
            builder.setRedirectURL(customInboundResponse.getRedirectUrl());
        } else if (customInboundResponse.getRequestMethod().equals("POST")) {
            builder.setStatusCode(HttpServletResponse.SC_OK);
            builder.setContentType(MediaType.TEXT_HTML);
            builder.setBody(getRedirectHtml(customInboundResponse.getRedirectUrl(), customInboundResponse.getUserName(),
                    customInboundResponse.getPassword()));
        }
        return builder;
    }

    @Override
    public void create(
            HttpIdentityResponse.HttpIdentityResponseBuilder builder, IdentityResponse identityResponse) {
        this.create(identityResponse);
    }

    /**
     * Creates the html page containing the HTTP POST request including form params (username and password).
     * @param acUrl where the response should be redirected
     * @param username authenticated user's username to be added as a form param
     * @param password authenticated user's password to be added as a form param
     * @return html page that contains the acUrl and username, password as POST action form params
     */
    private String getRedirectHtml(String acUrl, String username, String password) {

        String htmlPage = CustomInboundAuthConfig.getInstance().getSsoResponseHtml();
        String pageWithAcs = htmlPage.replace("$acUrl", acUrl);
        String pageWithAcsAndUsername = pageWithAcs.replace("$username", username);
        String pageWithAcsAndCredentials = pageWithAcsAndUsername.replace("$password", password);
        if (logger.isDebugEnabled()) {
            logger.debug("response.html " + pageWithAcsAndCredentials);
        }
        return pageWithAcsAndCredentials;
    }

}
