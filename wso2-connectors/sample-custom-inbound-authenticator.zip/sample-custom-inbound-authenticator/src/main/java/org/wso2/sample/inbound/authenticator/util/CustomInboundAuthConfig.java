package org.wso2.sample.inbound.authenticator.util;

import org.wso2.carbon.identity.application.common.model.InboundProvisioningConnector;
import org.wso2.carbon.identity.application.common.model.Property;
import org.wso2.carbon.identity.application.mgt.AbstractInboundAuthenticatorConfig;

/**
 * This class is a subclass of {@link AbstractInboundAuthenticatorConfig} which can be used for populating the GUI
 * elements for the custom inbound authenticator in the Identity Server's SP configuration
 */
public class CustomInboundAuthConfig extends AbstractInboundAuthenticatorConfig
        implements InboundProvisioningConnector {

    private static final String NAME = "sample-custom-inbound-type";
    private static CustomInboundAuthConfig instance = new CustomInboundAuthConfig();

    /**
     * This ssoResponseHtml page will be used to do the POST request to acUrl with the username and password as form params
     * if the request method specified in the Service Provider configuration is POST.
     */
    private String ssoResponseHtml = "<html>\n" +
            "\t<body>\n" +
            "        \t<p>You are now redirected back to $acUrl \n" +
            "        \tIf the redirection fails, please click the post button.</p>\n" +
            "\n" +
            "        \t<form method='post' action='$acUrl'>\n" +
            "       \t\t\t<p>\n" +
            "\t\t\t\t\t<!--$params-->\n" +
            "                    <!--$additionalParams-->\n" +
            "        \t\t\t<button type='submit'>POST</button>\n" +
            "        \t\t\t<input type='hidden' name='Username' value='$username'>\n" +
            "        \t\t\t<input type='hidden' name='Password' value='$password'>\n" +
            "       \t\t\t</p>\n" +
            "       \t\t</form>\n" +
            "       \t\t<script type='text/javascript'>\n" +
            "        \t\tdocument.forms[0].submit();\n" +
            "        \t</script>\n" +
            "        </body>\n" +
            "</html>";

    public CustomInboundAuthConfig() {

    }

    public static CustomInboundAuthConfig getInstance() {
        return instance;
    }

    @Override
    public String getName() {
        return NAME;
    }

    @Override
    public String getConfigName() {
        return NAME;
    }


    @Override
    public String getFriendlyName() {
        // The human-readable name that gets printed in the SP config
        return "Salient COTS Authenticator";
    }

    /**
     * Defines which field should be used against the value from the request in picking up what SP config to use against
     * the request (see document).
     * @return the name of the field in the property map defined in getConfigurationProperties() whose value will be
     * unique for a protocol.
     */
    @Override
    public String getRelyingPartyKey() {
        return "relying-party-field";
    }

    /**
     * This method helps define all property fields that will be shown in the SP config page.
     * @return an array of properties to be populated in the SP GUI.
     */
    @Override
    public Property[] getConfigurationProperties() {

        Property relParty = new Property();
        relParty.setName("relying-party-field");
        relParty.setDisplayName("Relying Party");

        Property redirectUrl = new Property();
        redirectUrl.setName("redirect-url");
        redirectUrl.setDisplayName("Redirect URL");

        Property requestMethod = new Property();
        requestMethod.setName("request-method");
        requestMethod.setDisplayName("Request Method");

        return new Property[]{relParty, redirectUrl, requestMethod};
    }

    public String getSsoResponseHtml() {
        return ssoResponseHtml;
    }
}
