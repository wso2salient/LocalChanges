package org.wso2.carbon.identity.application.ttb.authenticator.basicauth.internal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.service.component.ComponentContext;
import org.wso2.carbon.identity.application.authentication.framework.ApplicationAuthenticator;
import org.wso2.carbon.identity.application.ttb.authenticator.basicauth.TTBCustomAuthenticator;
import org.wso2.carbon.user.core.service.RealmService;

/**
 * @scr.component name="identity.application.authenticator.ttb.custom.component" immediate="true"
 * @scr.reference name="user.realmservice.default" interface="org.wso2.carbon.user.core.service.RealmService"
 * cardinality="1..1" policy="dynamic" bind="setRealmService" unbind="unsetRealmService"
 */

/*
This is the OSGi service component for the custom basic authenticator. This will enable the bundle (jar) to
 activate the specified service and register themselves so that the IS is able to see them and use them when a
 matching request arrives.
*/
public class TTBCustomAuthenticatorServiceComponent {

    private static final Log log = LogFactory.getLog( TTBCustomAuthenticatorServiceComponent.class);

    private static RealmService realmService;

    public static RealmService getRealmService() {
        return realmService;
    }

    protected void activate(ComponentContext ctxt) {
        try {

            TTBCustomAuthenticator basicCustomAuthenticator = new TTBCustomAuthenticator();
            ctxt.getBundleContext().registerService(ApplicationAuthenticator.class.getName(),
                    basicCustomAuthenticator, null);

            if (log.isDebugEnabled()) {
                log.debug("TTB Custom Authenticator bundle is activated.");
            }

        } catch (Throwable e) {
            log.fatal("Error while activating TTB custom authenticator bundle.", e);
        }
    }

    protected void deactivate(ComponentContext ctxt) {
        if (log.isDebugEnabled()) {
            log.debug("TTB custom  Authenticator bundle is deactivated.");
        }
    }

    protected void setRealmService(RealmService realmService) {
        if (log.isDebugEnabled()) {
            log.debug("Setting the Realm Service");
        }
        this.realmService = realmService;
    }

    protected void unsetRealmService(RealmService realmService) {
        if (log.isDebugEnabled()) {
            log.debug("Unsetting the Realm Service");
        }
        this.realmService = null;
    }
}
